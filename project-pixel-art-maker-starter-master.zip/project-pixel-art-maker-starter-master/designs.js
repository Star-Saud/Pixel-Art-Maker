function makeGrid(event) {
    event.preventDefault();

    var height = document.getElementById("inputHeight").value;
    var width = document.getElementById("inputWidth").value;
    var tableCanvas = document.getElementById("pixelCanvas");

    tableCanvas.innerHTML = "";

    for (var y = 0; y < height; y++) {
        var row = document.createElement("tr");
        for (var x = 0; x < width; x++) {
            var cell = document.createElement("td");
            row.appendChild(cell);
        }
        tableCanvas.appendChild(row);
    }
}

 function highlightCell(event) {
    if (event.target.nodeName == "TD") {
        var pickedColor = document.getElementById("colorPicker").value;
        event.target.style.backgroundColor = pickedColor;
    }
}
